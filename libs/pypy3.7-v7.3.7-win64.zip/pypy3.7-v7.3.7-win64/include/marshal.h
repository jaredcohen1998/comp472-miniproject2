#ifndef Py_MARSHAL_H
#define Py_MARSHAL_H
#ifdef __cplusplus
extern "C" {
#endif

#define Py_MARSHAL_VERSION 2
#include "pypy_marshal_decl.h"

#ifdef __cplusplus
}
#endif
#endif /* !Py_MARSHAL_H */
