import py

udir = py.path.local.make_numbered_dir(prefix = 'ffi-')
